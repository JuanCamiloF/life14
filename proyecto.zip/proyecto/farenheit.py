from flask import Flask, request, jsonify, render_template
import tensorflow as tf
import numpy as np
import threading
import webbrowser

# Cargar el modelo
modelo = tf.keras.models.load_model("farenheit_a_celsius.h5")

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/convertir", methods=["POST"])
def convertir():
    datos = request.get_json()
    fahrenheit = datos.get("fahrenheit")  # ✅ con h

    if fahrenheit is None:
        return jsonify({"error": "Dato faltante"}), 400

    try:
        entrada = np.array([[fahrenheit]], dtype=np.float32)
        celsius = modelo.predict(entrada)[0][0]
        return jsonify({"celsius": round(float(celsius), 2)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def abrir_navegador():
    webbrowser.open_new("http://127.0.0.1:5000/")

if __name__ == "__main__":
    threading.Timer(1.25, abrir_navegador).start()
    app.run(debug=True)