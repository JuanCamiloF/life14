function convertir() {
  const f = parseFloat(document.getElementById("farenheit").value);
  if (isNaN(f)) {
    document.getElementById("resultado").textContent = "Por favor ingrese un número válido.";
    return;
  }

  fetch("http://127.0.0.1:5000/convertir", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ fahrenheit: f })
  })
  .then(response => response.json())
  .then(data => {
    if (data.celsius !== undefined) {
      document.getElementById("resultado").textContent = `${f} °F son ${data.celsius} °C`;
    } else {
      document.getElementById("resultado").textContent = "Error en la conversión.";
    }
  })
  .catch(error => {
    console.error("Error:", error);
    document.getElementById("resultado").textContent = "No se pudo conectar con el servidor.";
  });
}