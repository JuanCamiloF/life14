import tensorflow as tf
import numpy as np
from tensorflow import keras

# Datos
farenheit = np.array ([21,14,18,27,39,48,65,88,93,111], dtype=np.float32 )
celsius =  np.array([-11.1111,-10,-7.7778,-2.7778,3.8889,8.8889,18.3333,31.1111,35,43.8889], dtype=np.float32)


# Crear el modelo
model = tf.keras.Sequential([
    tf.keras.layers.Dense(units=10, input_shape=[1]),
    tf.keras.layers.Dense(units=155, activation='linear'),
    tf.keras.layers.Dense(units=1)
])

# Compilar el modelo
model.compile(optimizer="adam", loss="mean_squared_error")

# Entrenar el modelo
model.fit(farenheit, celsius, epochs=500, verbose=False)

# Predicción: convierte a array de numpy
f = 35
resultado = model.predict(np.array([f], dtype=np.float32))
print(f"{f} grados Fahrenheit son: {resultado[0][0]:.2f} grados centígrados")

model.save("farenheit_a_celsius.h5")